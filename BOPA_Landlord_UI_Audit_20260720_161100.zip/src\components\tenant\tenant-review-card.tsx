"use client";

import { useActionState } from "react";
import { ExternalLink, FileText } from "lucide-react";
import {
  approveTenantAction,
  rejectTenantAction,
  waitlistTenantAction,
} from "@/actions/tenants.actions";
import { initialTenantActionState } from "@/actions/tenant.state";
import { ActionResultToast } from "@/components/ui/action-result-toast";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import type { GuarantorRow } from "@/server/repositories/guarantors.repository";
import type { TenantListRow } from "@/server/repositories/tenants.repository";
import type { SignedKycDocument } from "@/server/services/storage.service";
import {
  isSubmittedForLandlordReview,
  TENANT_ONBOARDING_STATUSES,
} from "@/server/constants/onboarding-lifecycle";

type KycDocumentLinks = {
  tenantIdDocument: SignedKycDocument;
  tenantPassportPhoto: SignedKycDocument;
  guarantorIdDocument: SignedKycDocument;
};

type TenantReviewCardProps = {
  tenant: TenantListRow;
  guarantor: GuarantorRow | null;
  documents: KycDocumentLinks;
};

function formatDate(value: string | null) {
  if (!value) {
    return "Not provided";
  }

  return new Intl.DateTimeFormat("en-NG", {
    dateStyle: "medium",
  }).format(new Date(value));
}

function idTypeLabel(value: TenantListRow["id_type"]) {
  if (value === "nin") {
    return "NIN";
  }

  if (value === "passport") {
    return "International Passport";
  }

  if (value === "drivers_license") {
    return "Driver's License";
  }

  if (value === "voters_card") {
    return "Voter's Card";
  }

  return "Not provided";
}

function DetailItem({
  label,
  value,
}: {
  label: string;
  value: string | null | undefined;
}) {
  return (
    <div className="rounded-button bg-background p-4">
      <p className="text-sm font-bold text-text-muted">{label}</p>
      <p className="mt-2 wrap-break-word font-extrabold text-text-strong">
        {value || "Not provided"}
      </p>
    </div>
  );
}

function DocumentItem({ document }: { document: SignedKycDocument }) {
  const hasDocument = Boolean(document.path && document.signedUrl);

  return (
    <div className="rounded-button bg-background p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="flex size-10 shrink-0 items-center justify-center rounded-2xl bg-primary-soft text-primary">
            <FileText aria-hidden="true" size={20} strokeWidth={2.6} />
          </div>

          <div>
            <p className="text-sm font-extrabold text-text-strong">
              {document.label}
            </p>
            <p className="mt-1 break-all text-xs font-semibold leading-5 text-text-muted">
              {document.path || "Not uploaded"}
            </p>
          </div>
        </div>

        {hasDocument ? (
          <a
            href={document.signedUrl ?? "#"}
            target="_blank"
            rel="noreferrer"
            className="inline-flex shrink-0 items-center gap-1 rounded-button bg-white px-3 py-2 text-xs font-extrabold text-primary shadow-soft ring-1 ring-border-soft transition hover:bg-primary-soft"
          >
            View
            <ExternalLink aria-hidden="true" size={14} strokeWidth={2.6} />
          </a>
        ) : (
          <Badge tone="neutral">Missing</Badge>
        )}
      </div>
    </div>
  );
}

export function TenantReviewCard({
  tenant,
  guarantor,
  documents,
}: TenantReviewCardProps) {
  const [approveState, approveFormAction, isApproving] = useActionState(
    approveTenantAction,
    initialTenantActionState,
  );

  const [rejectState, rejectFormAction, isRejecting] = useActionState(
    rejectTenantAction,
    initialTenantActionState,
  );

  const [waitlistState, waitlistFormAction, isWaitlisting] = useActionState(
    waitlistTenantAction,
    initialTenantActionState,
  );

  const canReview =
    isSubmittedForLandlordReview(tenant.onboarding_status) ||
    tenant.onboarding_status === TENANT_ONBOARDING_STATUSES.waitlisted;
  const isApproved = tenant.onboarding_status === TENANT_ONBOARDING_STATUSES.approved;
  const isRejected = tenant.onboarding_status === TENANT_ONBOARDING_STATUSES.rejected;
  const isWaitlisted =
    tenant.onboarding_status === TENANT_ONBOARDING_STATUSES.waitlisted;

  if (tenant.onboarding_status === TENANT_ONBOARDING_STATUSES.invited) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Tenant Review</CardTitle>
        </CardHeader>

        <CardContent>
          <div className="rounded-button bg-warning-soft p-4 text-sm font-semibold leading-6 text-warning">
            The tenant has not submitted their KYC profile yet. Generate or send
            the onboarding link and wait for submission.
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <ActionResultToast
        ok={approveState.ok}
        message={approveState.message}
        successTitle="Tenant approved"
        errorTitle="Approval failed"
      />

      <ActionResultToast
        ok={rejectState.ok}
        message={rejectState.message}
        successTitle="Tenant rejected"
        errorTitle="Rejection failed"
      />

      <ActionResultToast
        ok={waitlistState.ok}
        message={waitlistState.message}
        successTitle="Tenant waitlisted"
        errorTitle="Waitlist failed"
      />

      <CardHeader>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <CardTitle>Tenant Review</CardTitle>
            <p className="mt-1 text-sm leading-6 text-text-muted">
              Review submitted KYC, documents, and guarantor details before
              approving this tenant.
            </p>
          </div>

          <Badge
            tone={isApproved ? "success" : isRejected ? "danger" : "primary"}
          >
            {isApproved
              ? "Approved"
              : isRejected
                ? "Rejected"
                : isWaitlisted
                  ? "Waitlisted"
                  : "Ready for review"}
          </Badge>
        </div>
      </CardHeader>

      <CardContent>
        {isRejected && tenant.rejected_reason ? (
          <div className="mb-5 rounded-button bg-danger-soft p-4 text-sm font-semibold leading-6 text-danger">
            Rejection reason: {tenant.rejected_reason}
          </div>
        ) : null}

        {isWaitlisted && tenant.waitlist_reason ? (
          <div className="mb-5 rounded-button bg-warning-soft p-4 text-sm font-semibold leading-6 text-warning">
            Waitlist reason: {tenant.waitlist_reason}
          </div>
        ) : null}

        <div className="space-y-5">
          <div>
            <h3 className="text-sm font-extrabold text-text-strong">
              Submitted Tenant Details
            </h3>

            <div className="mt-3 grid gap-4 md:grid-cols-2">
              <DetailItem label="Full name" value={tenant.full_name} />
              <DetailItem label="Phone number" value={tenant.phone_number} />
              <DetailItem label="Email" value={tenant.email} />
              <DetailItem
                label="Date of birth"
                value={formatDate(tenant.date_of_birth)}
              />
              <DetailItem label="Home address" value={tenant.home_address} />
              <DetailItem label="Occupation" value={tenant.occupation} />
              <DetailItem label="Employer" value={tenant.employer} />
              <DetailItem label="ID type" value={idTypeLabel(tenant.id_type)} />
            </div>
          </div>

          <div>
            <h3 className="text-sm font-extrabold text-text-strong">
              Submitted Documents
            </h3>

            <div className="mt-3 grid gap-4">
              <DocumentItem document={documents.tenantIdDocument} />
              <DocumentItem document={documents.tenantPassportPhoto} />
              <DocumentItem document={documents.guarantorIdDocument} />
            </div>
          </div>

          <div>
            <h3 className="text-sm font-extrabold text-text-strong">
              Guarantor Details
            </h3>

            {guarantor ? (
              <div className="mt-3 grid gap-4 md:grid-cols-2">
                <DetailItem label="Full name" value={guarantor.full_name} />
                <DetailItem
                  label="Phone number"
                  value={guarantor.phone_number}
                />
                <DetailItem label="Email" value={guarantor.email} />
                <DetailItem
                  label="Relationship"
                  value={guarantor.relationship_to_tenant}
                />
                <DetailItem label="Address" value={guarantor.address} />
              </div>
            ) : (
              <div className="mt-3 rounded-button bg-warning-soft p-4 text-sm font-semibold leading-6 text-warning">
                No guarantor details have been submitted yet.
              </div>
            )}
          </div>

          {canReview ? (
            <div className="space-y-4">
              <div className="grid gap-4 lg:grid-cols-2">
                <form action={approveFormAction}>
                  <input type="hidden" name="tenantId" value={tenant.id} />

                  <Button type="submit" isLoading={isApproving} fullWidth>
                    Approve Tenant
                  </Button>
                </form>

                <form action={rejectFormAction} className="space-y-3">
                  <input type="hidden" name="tenantId" value={tenant.id} />

                  <Textarea
                    label="Reason for rejection"
                    name="reason"
                    placeholder="Example: ID details could not be verified."
                    error={rejectState.fieldErrors?.reason?.[0]}
                    required
                  />

                  <Button
                    type="submit"
                    variant="secondary"
                    isLoading={isRejecting}
                    fullWidth
                  >
                    Reject Tenant
                  </Button>
                </form>
              </div>

              <form action={waitlistFormAction} className="space-y-3">
                <input type="hidden" name="tenantId" value={tenant.id} />

                <Textarea
                  label="Reason for waitlist"
                  name="reason"
                  placeholder="Example: Strong candidate, pending unit availability."
                  error={waitlistState.fieldErrors?.reason?.[0]}
                  required
                />

                <Button
                  type="submit"
                  variant="ghost"
                  isLoading={isWaitlisting}
                  fullWidth
                >
                  Waitlist Tenant
                </Button>
              </form>
            </div>
          ) : null}
        </div>
      </CardContent>

      <CardFooter>
        <p className="text-sm leading-6 text-text-muted">
          Approval allows the landlord to proceed with the tenancy record,
          agreement document, and payment-link flow.
        </p>
      </CardFooter>
    </Card>
  );
}
