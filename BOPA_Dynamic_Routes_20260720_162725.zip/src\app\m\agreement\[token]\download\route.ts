import { NextResponse } from "next/server";
import { isAppError } from "@/server/errors/app-error";
import { getManagerTenancyAgreementPdfDownload } from "@/server/services/manager-tenancy-agreement-pdf.service";
import { resolveManagerTenantAgreementToken } from "@/server/services/manager-tenant-onboarding.service";
import { createSupabaseAdminClient } from "@/server/supabase/admin";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const revalidate = 0;

type ManagerAgreementDownloadRouteProps = {
  params: Promise<{
    token: string;
  }>;
};

export async function GET(
  _request: Request,
  { params }: ManagerAgreementDownloadRouteProps,
) {
  try {
    const { token } = await params;
    const agreement = await resolveManagerTenantAgreementToken(token);
    const download = await getManagerTenancyAgreementPdfDownload({
      supabase: createSupabaseAdminClient(),
      agreement,
    });

    return new NextResponse(download.fileBuffer, {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${download.fileName}"`,
        "Cache-Control": "private, no-store",
      },
    });
  } catch (error) {
    if (isAppError(error)) {
      return NextResponse.json(
        {
          ok: false,
          message: error.userMessage,
        },
        {
          status: error.status,
        },
      );
    }

    return NextResponse.json(
      {
        ok: false,
        message: "Agreement could not be downloaded.",
      },
      {
        status: 500,
      },
    );
  }
}
